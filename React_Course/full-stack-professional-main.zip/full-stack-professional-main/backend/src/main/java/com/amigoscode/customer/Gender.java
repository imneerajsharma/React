package com.amigoscode.customer;

public enum Gender {
    MALE,
    FEMALE
}
